Letakkan file logo Anda di folder ini dengan nama: logo.jpg

Nama file yang direkomendasikan: logo.jpg
Ukuran saran: 200x200 (atau persegi), format JPG/JPEG atau WebP.

Untuk menyalin file dari Downloads ke folder proyek, jalankan perintah PowerShell berikut (jalankan di PowerShell):

```powershell
Copy-Item "C:\Users\DELL\Downloads\IMG-20210410-WA0013.jpg" -Destination "C:\Users\DELL\Downloads\website arsyila\website_files\assets\images\logo.jpg" -Force
```

Setelah itu, refresh halaman `index.html` di browser (F5). Jika logo belum pas ukurannya, beri tahu saya, saya akan sesuaikan CSS ukuran.